package com.carrefour.customer.delivery.enums;

public enum ExceptionDeliveryType {
    TECHNICAL_EXCEPTION,
    TOKEN_INVALID_EXCEPTION;
}
